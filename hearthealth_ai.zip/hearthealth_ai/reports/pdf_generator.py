"""
HeartHealth AI - Dynamic PDF Report Generator
Generates clinical-grade educational PDF summary reports using ReportLab.
"""
import io
import os
import base64
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, KeepTogether, HRFlowable
)
from reportlab.lib.units import inch

# Palette
DARK_NAVY = colors.HexColor('#0F172A')
RED_ALERT = colors.HexColor('#DC2626')
SLATE = colors.HexColor('#64748B')
LIGHT_GREY = colors.HexColor('#F1F5F9')
BORDER_COLOR = colors.HexColor('#CBD5E1')
WHITE = colors.HexColor('#FFFFFF')

class ReportGenerator:
    @staticmethod
    def generate_pdf(assessment, shap_data=None, recommendations=None):
        """
        Creates a PDF binary stream from an assessment model instance.
        """
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=36,
            leftMargin=36,
            topMargin=36,
            bottomMargin=36
        )

        styles = getSampleStyleSheet()

        # Custom Typography Styles
        title_style = ParagraphStyle(
            'ReportTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=22,
            leading=26,
            textColor=DARK_NAVY,
            spaceAfter=4
        )

        subtitle_style = ParagraphStyle(
            'ReportSubtitle',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=10,
            leading=14,
            textColor=SLATE
        )

        h2_style = ParagraphStyle(
            'SectionH2',
            parent=styles['Heading2'],
            fontName='Helvetica-Bold',
            fontSize=13,
            leading=16,
            textColor=DARK_NAVY,
            spaceBefore=12,
            spaceAfter=6
        )

        body_style = ParagraphStyle(
            'BodyText',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=9.5,
            leading=13,
            textColor=DARK_NAVY
        )

        disclaimer_style = ParagraphStyle(
            'DisclaimerText',
            parent=styles['Normal'],
            fontName='Helvetica-Oblique',
            fontSize=8,
            leading=11,
            textColor=SLATE
        )

        elements = []

        # 1. Header Banner
        header_table_data = [
            [
                Paragraph("<b>HEARTHEALTH AI</b><br/><font size=8 color='#64748B'>CLINICAL DECISION SUPPORT & EDUCATIONAL PLATFORM</font>", title_style),
                Paragraph(f"<b>Assessment ID:</b> #{assessment.id}<br/><b>Date:</b> {assessment.created_at.strftime('%Y-%m-%d %H:%M')}<br/><b>Status:</b> Complete", subtitle_style)
            ]
        ]
        header_table = Table(header_table_data, colWidths=[3.8*inch, 3.2*inch])
        header_table.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
        ]))
        elements.append(header_table)
        elements.append(HRFlowable(width="100%", thickness=2, color=DARK_NAVY, spaceBefore=8, spaceAfter=12))

        # 2. Executive Summary Block
        result_color = RED_ALERT if assessment.prediction == 1 else DARK_NAVY
        pred_text = "HEART DISEASE INDICATED (ELEVATED PATTERN RISK)" if assessment.prediction == 1 else "NO HEART DISEASE INDICATED (LOW PATTERN RISK)"
        
        summary_cell = [
            Paragraph(f"<b>PREDICTION RESULT:</b> <font color='{result_color.hexval()}'><b>{pred_text}</b></font>", h2_style),
            Paragraph(f"<b>Model Probability:</b> {assessment.probability_pct:.1f}% &nbsp;|&nbsp; <b>Model:</b> {assessment.model_name} &nbsp;|&nbsp; <b>Risk Tier:</b> {assessment.risk_tier}", body_style),
            Paragraph("<i>Educational machine learning output reflecting statistical pattern alignment with training cohort. Not a diagnostic confirmation.</i>", disclaimer_style)
        ]
        summary_table = Table([[summary_cell]], colWidths=[7.0*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), LIGHT_GREY),
            ('BOX', (0, 0), (-1, -1), 1.5, result_color),
            ('PADDING', (0, 0), (-1, -1), 10),
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 12))

        # 3. Patient Details & Clinical Parameters Table
        elements.append(Paragraph("1. Submitted Clinical Parameters", h2_style))
        params_data = [
            [
                Paragraph("<b>Parameter</b>", body_style),
                Paragraph("<b>Recorded Value</b>", body_style),
                Paragraph("<b>Parameter</b>", body_style),
                Paragraph("<b>Recorded Value</b>", body_style)
            ],
            [
                "Age", f"{assessment.age} years",
                "Gender", f"{assessment.gender}"
            ],
            [
                "Resting Blood Pressure", f"{assessment.resting_bp} mmHg",
                "Total Cholesterol", f"{assessment.cholesterol} mg/dL"
            ],
            [
                "Fasting Blood Sugar", f"{assessment.fasting_blood_sugar}",
                "Maximum Heart Rate", f"{assessment.max_heart_rate} bpm"
            ],
            [
                "Resting ECG", f"{assessment.resting_ecg}",
                "Exercise-Induced Angina", f"{assessment.exercise_angina}"
            ],
            [
                "Chest Pain Type", f"{assessment.chest_pain_type}",
                "ST Depression", f"{assessment.st_depression:.1f} mm"
            ],
            [
                "ST Slope", "Omitted (Feature not in dataset)",
                "Assessment Source", "Direct Patient Entry" if not assessment.uploaded_report_filename else f"Uploaded File ({assessment.uploaded_report_filename})"
            ]
        ]
        params_table = Table(params_data, colWidths=[1.8*inch, 1.7*inch, 1.8*inch, 1.7*inch])
        params_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), LIGHT_GREY),
            ('TEXTCOLOR', (0, 0), (-1, -1), DARK_NAVY),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
            ('PADDING', (0, 0), (-1, -1), 4.5),
        ]))
        elements.append(params_table)
        elements.append(Spacer(1, 12))

        # 4. Explainable AI (SHAP) Chart Section
        elements.append(Paragraph("2. Explainable AI Analysis (SHAP Feature Contributions)", h2_style))
        elements.append(Paragraph("Individual feature contributions calculated via Shapley Additive exPlanations (SHAP). Red indicators elevated the prediction score, while navy indicators lowered it.", body_style))
        elements.append(Spacer(1, 6))

        if shap_data and shap_data.get('importance_b64'):
            try:
                img_data = base64.b64decode(shap_data['importance_b64'])
                img_io = io.BytesIO(img_data)
                chart_img = RLImage(img_io, width=6.5*inch, height=3.0*inch)
                elements.append(chart_img)
            except Exception as e:
                elements.append(Paragraph(f"Chart embedding unavailable: {e}", disclaimer_style))
        elements.append(Spacer(1, 10))

        # 5. Personalized Recommendations
        if recommendations:
            elements.append(KeepTogether([
                Paragraph("3. Personalized Educational Recommendations", h2_style),
                Paragraph("Recommendations generated exclusively from your submitted health parameters:", body_style),
                Spacer(1, 4)
            ]))
            
            for item in recommendations.get('priority_items', [])[:4]:
                p_text = f"<b>• {item['title']}:</b> {item['description']}<br/><i>Recommended Action: {item['action']}</i>"
                elements.append(Paragraph(p_text, body_style))
                elements.append(Spacer(1, 4))

            for item in recommendations.get('lifestyle_advice', [])[:3]:
                l_text = f"<b>• {item['topic']}:</b> {item['tip']}"
                elements.append(Paragraph(l_text, body_style))
                elements.append(Spacer(1, 4))

        elements.append(Spacer(1, 10))

        # 6. Medical Disclaimer & Footer
        disclaimer_box = [
            Paragraph("<b>LEGAL & MEDICAL DISCLAIMER:</b>", ParagraphStyle('DisclHead', parent=disclaimer_style, fontName='Helvetica-Bold', textColor=RED_ALERT)),
            Paragraph(
                "HeartHealth AI is an educational machine learning platform designed for academic and health awareness purposes. "
                "The predictions and educational summaries provided herein do NOT constitute a medical diagnosis, clinical prognosis, "
                "or pharmacological prescription. All clinical management decisions must be guided by certified healthcare providers "
                "and diagnostic laboratory investigations. In any acute cardiac emergency, contact emergency medical services immediately.",
                disclaimer_style
            )
        ]
        disc_table = Table([[disclaimer_box]], colWidths=[7.0*inch])
        disc_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), LIGHT_GREY),
            ('BOX', (0, 0), (-1, -1), 1, BORDER_COLOR),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        elements.append(disc_table)

        # Build document
        doc.build(elements)
        buffer.seek(0)
        return buffer.getvalue()

pdf_generator = ReportGenerator()
