from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from predictions.models import PatientAssessment
from .recommendation_engine import RecommendationEngine

@login_required
def recommendations_view(request):
    assessment_id = request.GET.get('assessment_id')
    assessment = None
    if assessment_id:
        assessment = PatientAssessment.objects.filter(id=assessment_id, user=request.user).first()
    if not assessment:
        assessment = PatientAssessment.objects.filter(user=request.user).first()

    recommendations = None
    if assessment:
        recommendations = RecommendationEngine.generate_recommendations(
            assessment.to_input_dict(), assessment.prediction
        )

    user_assessments = PatientAssessment.objects.filter(user=request.user).order_by('-created_at')[:8]

    return render(request, 'recommendations/recommendations_view.html', {
        'assessment': assessment,
        'recommendations': recommendations,
        'user_assessments': user_assessments
    })
