# Recommendations app models
