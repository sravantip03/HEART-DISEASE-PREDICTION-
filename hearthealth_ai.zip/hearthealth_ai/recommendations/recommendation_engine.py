"""
HeartHealth AI - Personalized Health Recommendations Engine
Generates patient-tailored, educational, parameter-specific recommendations.
Does NOT prescribe medication or treatment; adheres to medical education ethics.
"""

class RecommendationEngine:
    @staticmethod
    def generate_recommendations(assessment_data, prediction_result):
        """
        Evaluates patient parameters and returns structured recommendations:
        - Priority Action Items (Urgent discussions for doctor)
        - Parameter Insights (BP, Lipids, Glucose, Exercise)
        - Lifestyle & Nutrition Guidelines
        - Follow-up Cardiac Screening Advice
        """
        recommendations = {
            'priority_items': [],
            'parameter_insights': [],
            'lifestyle_advice': [],
            'doctor_questions': []
        }

        # 1. Resting Blood Pressure Evaluation
        try:
            rbp = float(assessment_data.get('Resting_BP', 120))
        except (ValueError, TypeError):
            rbp = 120

        if rbp >= 140:
            recommendations['priority_items'].append({
                'category': 'Hypertension Alert',
                'severity': 'high',
                'title': f'Resting Blood Pressure Elevated ({int(rbp)} mmHg)',
                'description': 'Your resting systolic blood pressure is in the Stage 2 hypertension range. Elevated pressure places continuous mechanical stress on arterial walls and the left ventricle.',
                'action': 'Schedule a clinical blood pressure evaluation with your primary physician within 1 to 2 weeks for repeated manual measurements.'
            })
            recommendations['lifestyle_advice'].append({
                'topic': 'DASH Diet & Sodium Reduction',
                'tip': 'Consider adopting the Dietary Approaches to Stop Hypertension (DASH) eating plan: limit daily sodium intake to under 2,000 mg and increase dietary potassium through leafy greens and bananas.'
            })
        elif rbp >= 125:
            recommendations['parameter_insights'].append({
                'category': 'Pre-hypertension',
                'severity': 'medium',
                'title': f'Pre-Hypertensive Blood Pressure ({int(rbp)} mmHg)',
                'description': 'Your systolic reading is mildly elevated above ideal baseline (<120 mmHg). Early lifestyle modifications can prevent progression to hypertension.',
                'action': 'Monitor your blood pressure weekly at home and record a log for your healthcare provider.'
            })
        else:
            recommendations['parameter_insights'].append({
                'category': 'Blood Pressure',
                'severity': 'normal',
                'title': f'Optimal Blood Pressure ({int(rbp)} mmHg)',
                'description': 'Your resting systolic pressure is within the desirable normative range, helping preserve vascular compliance.'
            })

        # 2. Cholesterol Evaluation
        try:
            chol = float(assessment_data.get('Cholesterol', 200))
        except (ValueError, TypeError):
            chol = 200

        if chol >= 240:
            recommendations['priority_items'].append({
                'category': 'Hypercholesterolemia',
                'severity': 'high',
                'title': f'Significantly High Cholesterol ({int(chol)} mg/dL)',
                'description': 'Total serum cholesterol at or above 240 mg/dL accelerates atheroma formation and plaque build-up within coronary arteries.',
                'action': 'Request a comprehensive lipid profile (measuring LDL, HDL, and Triglycerides) from your physician to assess plaque vulnerability.'
            })
            recommendations['lifestyle_advice'].append({
                'topic': 'Dietary Fat Modulation',
                'tip': 'Reduce saturated fats (found in fatty meats and full-fat dairy) and eliminate trans fats. Incorporate soluble fiber (oats, legumes) and omega-3 rich fatty fish.'
            })
        elif chol >= 200:
            recommendations['parameter_insights'].append({
                'category': 'Borderline Cholesterol',
                'severity': 'medium',
                'title': f'Borderline High Cholesterol ({int(chol)} mg/dL)',
                'description': 'Your cholesterol is in the borderline elevated range (200-239 mg/dL). Plaque formation can begin silently at these levels.',
                'action': 'Incorporate plant sterols, increase dietary fiber, and re-test lipid panel in 3 to 6 months.'
            })
        else:
            recommendations['parameter_insights'].append({
                'category': 'Lipid Profile',
                'severity': 'normal',
                'title': f'Desirable Cholesterol Level ({int(chol)} mg/dL)',
                'description': 'Total cholesterol is under 200 mg/dL, an excellent indicator of low atherogenic circulating lipids.'
            })

        # 3. Fasting Blood Sugar
        fbs = str(assessment_data.get('Fasting_Blood_Sugar', 'Normal')).strip()
        if fbs.lower() in ['high', '1', 'elevated']:
            recommendations['priority_items'].append({
                'category': 'Glycemic Alert',
                'severity': 'high',
                'title': 'High Fasting Blood Sugar Indicated',
                'description': 'Elevated fasting glucose (>120 mg/dL) damages vascular endothelium over time and significantly magnifies coronary artery disease progression.',
                'action': 'Discuss an HbA1c test with your doctor to evaluate 3-month average blood glucose and rule out impaired glucose tolerance or diabetes.'
            })
            recommendations['lifestyle_advice'].append({
                'topic': 'Glycemic Management',
                'tip': 'Favor complex carbohydrates with a low glycemic index, avoid sugar-sweetened beverages, and pair meals with lean protein and fiber.'
            })

        # 4. Exercise Induced Angina
        angina = str(assessment_data.get('Exercise_Angina', 'No')).strip()
        if angina.lower() in ['yes', '1', 'true']:
            recommendations['priority_items'].append({
                'category': 'Symptom Flag',
                'severity': 'high',
                'title': 'Exercise-Induced Angina Reported',
                'description': 'Chest discomfort triggered by exertion is a hallmark sign that cardiac oxygen demand exceeds coronary blood supply.',
                'action': 'Do NOT begin intense vigorous workouts before undergoing a formal treadmill stress test or cardiology consultation.'
            })
        
        # 5. Chest Pain Type
        cpt = str(assessment_data.get('Chest_Pain_Type', 'Asymptomatic')).strip()
        if cpt in ['Typical Angina', 'Atypical Angina']:
            recommendations['priority_items'].append({
                'category': 'Chest Discomfort Flag',
                'severity': 'high' if cpt == 'Typical Angina' else 'medium',
                'title': f'{cpt} Symptoms Reported',
                'description': f'Your report indicates {cpt.lower()}. Typical angina often indicates ischemia, while atypical angina warrants thorough non-invasive evaluation.',
                'action': 'Consult a cardiologist for coronary calcium scoring or stress echocardiography.'
            })

        # 6. ST Depression
        try:
            st_dep = float(assessment_data.get('ST_Depression', 0.0))
        except (ValueError, TypeError):
            st_dep = 0.0

        if st_dep >= 2.0:
            recommendations['priority_items'].append({
                'category': 'Electrocardiographic Indicator',
                'severity': 'high',
                'title': f'Significant ST Depression ({st_dep:.1f} mm)',
                'description': 'ST-segment horizontal or down-sloping depression >= 2.0 mm strongly correlates with subendocardial myocardial ischemia under physiological stress.',
                'action': 'Bring this ECG finding to a cardiologist for formal 12-lead ECG review and myocardial perfusion imaging.'
            })

        # 7. Maximum Heart Rate & Age
        try:
            age = int(assessment_data.get('Age', 50))
            max_hr = int(assessment_data.get('Max_Heart_Rate', 150))
            expected_peak = 220 - age
            hr_ratio = max_hr / expected_peak
            if hr_ratio < 0.70:
                recommendations['parameter_insights'].append({
                    'category': 'Chronotropic Response',
                    'severity': 'medium',
                    'title': f'Subdued Peak Heart Rate ({max_hr} bpm)',
                    'description': f'Your maximum recorded heart rate is {round(hr_ratio*100)}% of your age-predicted peak ({expected_peak} bpm), which could reflect chronotropic incompetence or beta-blocker medications.'
                })
        except Exception:
            pass

        # 8. Questions to ask the Doctor
        recommendations['doctor_questions'] = [
            "Based on my blood pressure and lipid profile, do I need a 10-year ASCVD risk calculation?",
            "Would a coronary artery calcium (CAC) scan or stress ECG be appropriate for my symptom profile?",
            "What target levels should I aim for regarding LDL cholesterol and systolic blood pressure?",
            "Are there safe guidelines and heart rate zones I should follow for cardiovascular exercise?"
        ]

        return recommendations
