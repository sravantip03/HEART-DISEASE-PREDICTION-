# HeartHealth AI – Medical Heart Disease Prediction Web Application

HeartHealth AI is a medical-grade educational cardiovascular decision support platform built with **Django**, **Scikit-learn**, **SHAP (SHapley Additive exPlanations)**, and **ReportLab**. The application allows patients and clinicians to enter health parameters or upload medical reports, predict the likelihood of heart disease using a trained machine learning pipeline, explore transparent feature-by-feature SHAP waterfall charts, receive personalized clinical recommendations, interact with an AI health assistant, and export dynamic PDF reports.

---

## 1. Key Application Capabilities

1. **Patient Prediction Engine**:
   - Collects 10 core clinical parameters matching the uploaded dataset: `Age`, `Gender`, `Chest_Pain_Type`, `Resting_BP`, `Cholesterol`, `Fasting_Blood_Sugar`, `Resting_ECG`, `Max_Heart_Rate`, `Exercise_Angina`, `ST_Depression`.
   - *ST Slope handling*: Explicitly identified as absent from the dataset and omitted without data fabrication.
2. **Medical Report Upload & OCR**:
   - Accepts `.pdf`, `.png`, and `.jpg` medical laboratory panels (up to 10MB).
   - Extracts readable text using `pdfplumber` / `pypdf` and Windows native OCR (`winocr`).
   - Identifies detectable parameters and allows users to review and confirm values before auto-filling the assessment form.
3. **Explainable AI (SHAP)**:
   - Eliminates black-box predictions by generating exact mathematical Shapley feature attributions.
   - Generates interactive, high-resolution horizontal bar charts and cumulative waterfall progression plots.
   - Provides clear, plain-language narrative breakdowns of risk-elevating vs. protective factors.
4. **AI Health Assessment Assistant**:
   - Context-aware conversational assistant that injects the current patient assessment into the prompt.
   - Answers inquiries regarding blood pressure guidelines, lipid profiles, ECG abnormalities, and SHAP charts.
   - Medical safety guardrails: strict non-diagnostic disclaimers, refusal to prescribe or change medications, and immediate emergency triage for acute cardiovascular symptoms.
5. **Personalized Clinical Recommendations**:
   - Evaluates patient-specific risk factors (Stage 1/2 hypertension, hypercholesterolemia, fasting hyperglycemia, ischemia markers).
   - Provides DASH nutritional guidance, physical activity guidelines, and structured questions for doctor appointments.
6. **Longitudinal History & Comparison**:
   - Individual assessment history with date-range searching, outcome filtering, and record deletion.
   - Side-by-side assessment comparison view highlighting parameter deltas and trajectory improvements.
7. **Dynamic PDF Medical Report**:
   - Compiles a print-ready ReportLab medical summary with patient parameters, prediction results, SHAP charts, recommendations, and legal disclaimers.
8. **Heart Health Education Centre**:
   - 14 dedicated educational modules explaining atherosclerosis, risk factors, ECG waveforms, and heart-healthy lifestyle habits.

---

## 2. Machine Learning Architecture & Benchmark Results

The pipeline was trained, tuned, and evaluated on the uploaded 10,000-record dataset (`heart_disease_risk_prediction.csv`) using 5-fold Stratified Cross-Validation and a 20% holdout test set with zero data leakage.

| Model Algorithm | Hyperparameters | 5-Fold CV ROC-AUC | Test Accuracy | Test Precision | Test Recall | Test F1-Score | Test ROC-AUC | Status |
|---|---|---|---|---|---|---|---|---|
| **Gradient Boosting** | `learning_rate=0.05, max_depth=3, n_estimators=100` | **0.7722** | **77.95%** | **57.27%** | **26.97%** | **36.36%** | **0.7707** | **Selected Production Model** |
| **Random Forest** | `class_weight=None, max_depth=6, n_estimators=150` | 0.7730 | 78.35% | 59.18% | 24.07% | 33.08% | 0.7692 | Benchmarked |
| **Logistic Regression** | `C=0.1, class_weight=None` | 0.7626 | 78.40% | 61.06% | 26.35% | 37.39% | 0.7562 | Benchmarked |

- **Preprocessing Pipeline**: `StandardScaler` for continuous numerical features; `OneHotEncoder(drop='first', sparse_output=False, handle_unknown='ignore')` for categorical features.
- **Persistence**: Saved to `machine_learning/artifacts/best_model_pipeline.joblib`.

---

## 3. Technology Stack & Design Palette

- **Backend**: Python 3.12, Django 6.0
- **Machine Learning**: Scikit-learn, SHAP, Pandas, NumPy, Matplotlib, Seaborn, Joblib
- **PDF Generation**: ReportLab Platypus
- **Report Parsing**: `pdfplumber`, `pypdf`, `winocr`
- **Database**: SQLite3
- **Design Color Palette**:
  - **Dark Navy (`#0F172A`)**: Primary headers, navigation, cards, and stable metrics
  - **Red Alert (`#DC2626`)**: Risk highlights, emergency badges, action buttons
  - **Light Grey (`#F1F5F9`)**: Background canvas and secondary section fills
  - **Slate (`#64748B`)**: Subtitles, body descriptions, and secondary metadata

---

## 4. Quick Start & Execution Instructions

### Prerequisites
- Python 3.10+ installed.

### Setup and Running the Web Application

1. Open PowerShell or Command Prompt in the project folder:
   ```powershell
   cd C:\Users\srava\.gemini\antigravity\scratch\hearthealth_ai
   ```

2. (Optional) Create and activate a virtual environment:
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```

3. Install required packages:
   ```powershell
   pip install -r requirements.txt
   ```

4. Run database migrations:
   ```powershell
   python manage.py migrate
   ```

5. (Optional) Re-seed sample data if required:
   ```powershell
   python seed_demo.py
   ```

6. Launch the development server:
   ```powershell
   python manage.py runserver 127.0.0.1:8000
   ```

7. Open your web browser and navigate to:
   ```
   http://127.0.0.1:8000/
   ```

### Pre-Seeded Clinician Credentials
- **Username**: `doctor_demo`
- **Password**: `HealthAI2026!`

---

## 5. Medical Disclaimer

HeartHealth AI is an educational machine learning application designed for academic analysis and clinical decision support demonstration. Its predictions and risk estimations do NOT constitute a medical diagnosis, clinical prognosis, or pharmacological prescription. All diagnostic conclusions must be confirmed by certified medical professionals and diagnostic clinical testing. In case of acute cardiovascular symptoms (crushing chest pain, left arm pain, difficulty breathing), contact emergency medical services (911/112) immediately.
