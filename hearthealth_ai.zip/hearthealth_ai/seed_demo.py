import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hearthealth_ai.settings')
django.setup()

from django.contrib.auth.models import User
from accounts.models import PatientProfile
from predictions.models import PatientAssessment
from machine_learning.model_service import model_service
from explainable_ai.shap_service import shap_service

def seed():
    # 1. Create or get demo user
    username = 'doctor_demo'
    user, created = User.objects.get_or_create(username=username, defaults={
        'first_name': 'Eleanor',
        'last_name': 'Vance',
        'email': 'eleanor.vance@hearthealth.ai'
    })
    if created:
        user.set_password('HealthAI2026!')
        user.save()
        PatientProfile.objects.create(
            user=user,
            gender='Female',
            blood_group='O+',
            phone_number='+1 (555) 234-5678',
            emergency_contact='Dr. Arthur Vance (Spouse) +1 555-890-1234',
            medical_notes='Family history of premature coronary artery disease (maternal). No drug allergies.'
        )
        print(f"Created demo user: {username} / HealthAI2026!")
    else:
        print(f"Demo user {username} already exists.")

    # 2. Add sample assessment 1 (Elevated Risk)
    sample1_inputs = {
        'Age': 68,
        'Gender': 'Male',
        'Chest_Pain_Type': 'Typical Angina',
        'Resting_BP': 152,
        'Cholesterol': 248,
        'Fasting_Blood_Sugar': 'High',
        'Resting_ECG': 'ST-T Abnormality',
        'Max_Heart_Rate': 130,
        'Exercise_Angina': 'Yes',
        'ST_Depression': 2.8
    }

    pred1 = model_service.predict(sample1_inputs)
    shap1 = shap_service.explain_prediction(pred1['df'])

    a1 = PatientAssessment.objects.create(
        user=user,
        age=sample1_inputs['Age'],
        gender=sample1_inputs['Gender'],
        chest_pain_type=sample1_inputs['Chest_Pain_Type'],
        resting_bp=sample1_inputs['Resting_BP'],
        cholesterol=sample1_inputs['Cholesterol'],
        fasting_blood_sugar=sample1_inputs['Fasting_Blood_Sugar'],
        resting_ecg=sample1_inputs['Resting_ECG'],
        max_heart_rate=sample1_inputs['Max_Heart_Rate'],
        exercise_angina=sample1_inputs['Exercise_Angina'],
        st_depression=sample1_inputs['ST_Depression'],
        uploaded_report_filename='sample_cardiac_panel_A.pdf',
        prediction=pred1['prediction'],
        prediction_label=pred1['prediction_label'],
        probability=pred1['probability'],
        probability_pct=pred1['probability_pct'],
        risk_tier=pred1['risk_tier'],
        model_name=pred1['model_name'],
        shap_data={
            'expected_value': shap1['expected_value'],
            'contributions': shap1['contributions'],
            'narrative': shap1['narrative'],
            'waterfall_b64': shap1['waterfall_b64'],
            'importance_b64': shap1['importance_b64']
        }
    )
    print(f"Created sample assessment 1: #{a1.id} ({a1.prediction_label}, {a1.probability_pct}%)")

    # 3. Add sample assessment 2 (Improved / Low Risk Follow-up)
    sample2_inputs = {
        'Age': 45,
        'Gender': 'Female',
        'Chest_Pain_Type': 'Non-anginal Pain',
        'Resting_BP': 114,
        'Cholesterol': 178,
        'Fasting_Blood_Sugar': 'Normal',
        'Resting_ECG': 'Normal',
        'Max_Heart_Rate': 175,
        'Exercise_Angina': 'No',
        'ST_Depression': 0.4
    }

    pred2 = model_service.predict(sample2_inputs)
    shap2 = shap_service.explain_prediction(pred2['df'])

    a2 = PatientAssessment.objects.create(
        user=user,
        age=sample2_inputs['Age'],
        gender=sample2_inputs['Gender'],
        chest_pain_type=sample2_inputs['Chest_Pain_Type'],
        resting_bp=sample2_inputs['Resting_BP'],
        cholesterol=sample2_inputs['Cholesterol'],
        fasting_blood_sugar=sample2_inputs['Fasting_Blood_Sugar'],
        resting_ecg=sample2_inputs['Resting_ECG'],
        max_heart_rate=sample2_inputs['Max_Heart_Rate'],
        exercise_angina=sample2_inputs['Exercise_Angina'],
        st_depression=sample2_inputs['ST_Depression'],
        uploaded_report_filename='',
        prediction=pred2['prediction'],
        prediction_label=pred2['prediction_label'],
        probability=pred2['probability'],
        probability_pct=pred2['probability_pct'],
        risk_tier=pred2['risk_tier'],
        model_name=pred2['model_name'],
        shap_data={
            'expected_value': shap2['expected_value'],
            'contributions': shap2['contributions'],
            'narrative': shap2['narrative'],
            'waterfall_b64': shap2['waterfall_b64'],
            'importance_b64': shap2['importance_b64']
        }
    )
    print(f"Created sample assessment 2: #{a2.id} ({a2.prediction_label}, {a2.probability_pct}%)")
    print("Seed complete successfully!")

if __name__ == '__main__':
    seed()
