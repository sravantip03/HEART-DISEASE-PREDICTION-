"""
HeartHealth AI - Machine Learning Training Pipeline
Trains, tunes, compares Logistic Regression, Random Forest, and Gradient Boosting.
Saves the best model pipeline and evaluation metrics.
"""
import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix
)

def run_training():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_path = os.path.join(base_dir, 'dataset', 'heart_disease_risk_prediction.csv')
    artifacts_dir = os.path.join(base_dir, 'artifacts')
    os.makedirs(artifacts_dir, exist_ok=True)

    print(f"Loading dataset from: {dataset_path}")
    df = pd.read_csv(dataset_path)

    # 1. Dataset Auditing
    total_rows, total_cols = df.shape
    duplicates_count = int(df.duplicated().sum())
    target_distribution = df['Heart_Disease'].value_counts(normalize=True).to_dict()
    target_counts = df['Heart_Disease'].value_counts().to_dict()

    print(f"Dataset shape: {total_rows} rows, {total_cols} columns")
    print(f"Duplicate rows: {duplicates_count}")
    print(f"Target distribution: {target_counts}")

    # Core 10 features available in the dataset (ST_Slope is confirmed absent)
    core_features = [
        'Age',
        'Gender',
        'Chest_Pain_Type',
        'Resting_BP',
        'Cholesterol',
        'Fasting_Blood_Sugar',
        'Resting_ECG',
        'Max_Heart_Rate',
        'Exercise_Angina',
        'ST_Depression'
    ]

    numeric_features = ['Age', 'Resting_BP', 'Cholesterol', 'Max_Heart_Rate', 'ST_Depression']
    categorical_features = ['Gender', 'Chest_Pain_Type', 'Fasting_Blood_Sugar', 'Resting_ECG', 'Exercise_Angina']

    # Document feature distributions for validation & metadata
    feature_metadata = {
        "dataset_records": total_rows,
        "dataset_columns": total_cols,
        "st_slope_available": False,
        "st_slope_note": "The dataset does not contain ST_Slope. Excluded explicitly without fabrication.",
        "excluded_features": ["Patient_ID"],
        "core_features": core_features,
        "numeric_features": numeric_features,
        "categorical_features": categorical_features,
        "target_distribution": {str(k): int(v) for k, v in target_counts.items()},
        "numeric_stats": {},
        "categorical_options": {}
    }

    for col in numeric_features:
        feature_metadata["numeric_stats"][col] = {
            "min": float(df[col].min()),
            "max": float(df[col].max()),
            "mean": round(float(df[col].mean()), 2),
            "median": round(float(df[col].median()), 2),
            "std": round(float(df[col].std()), 2)
        }

    for col in categorical_features:
        feature_metadata["categorical_options"][col] = list(df[col].unique())

    # 2. Features and Target
    X = df[core_features].copy()
    y = df['Heart_Disease'].astype(int)

    # 3. Stratified Train-Test Split (80% Train, 20% Holdout Test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 4. Preprocessing Pipeline
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numeric_features),
            ('cat', OneHotEncoder(drop='first', sparse_output=False, handle_unknown='ignore'), categorical_features)
        ]
    )

    preprocessor.fit(X_train)
    encoded_feature_names = list(preprocessor.get_feature_names_out())
    feature_metadata["encoded_feature_names"] = encoded_feature_names

    # 5. Model Definitions and Hyperparameter Tuning Grids
    models_config = {
        'Logistic Regression': {
            'estimator': LogisticRegression(random_state=42, max_iter=1000),
            'param_grid': {
                'classifier__C': [0.1, 1.0, 5.0],
                'classifier__class_weight': ['balanced', None]
            }
        },
        'Random Forest': {
            'estimator': RandomForestClassifier(random_state=42),
            'param_grid': {
                'classifier__n_estimators': [100, 150],
                'classifier__max_depth': [6, 8, 10],
                'classifier__class_weight': ['balanced', None]
            }
        },
        'Gradient Boosting': {
            'estimator': GradientBoostingClassifier(random_state=42),
            'param_grid': {
                'classifier__n_estimators': [100, 150],
                'classifier__learning_rate': [0.05, 0.1],
                'classifier__max_depth': [3, 4]
            }
        }
    }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    comparison_results = {}
    fitted_pipelines = {}

    print("\nStarting Hyperparameter Tuning and Cross-Validation...")

    for model_name, config in models_config.items():
        print(f"\nTuning {model_name}...")
        pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('classifier', config['estimator'])
        ])

        grid_search = GridSearchCV(
            pipeline,
            config['param_grid'],
            cv=cv,
            scoring='roc_auc',
            n_jobs=-1,
            refit=True
        )

        grid_search.fit(X_train, y_train)
        best_pipeline = grid_search.best_estimator_
        fitted_pipelines[model_name] = best_pipeline

        # Training evaluations
        y_train_pred = best_pipeline.predict(X_train)
        y_train_proba = best_pipeline.predict_proba(X_train)[:, 1]

        # Test evaluations
        y_test_pred = best_pipeline.predict(X_test)
        y_test_proba = best_pipeline.predict_proba(X_test)[:, 1]

        # Metrics calculation
        train_acc = accuracy_score(y_train, y_train_pred)
        train_prec = precision_score(y_train, y_train_pred, zero_division=0)
        train_rec = recall_score(y_train, y_train_pred, zero_division=0)
        train_f1 = f1_score(y_train, y_train_pred, zero_division=0)
        train_auc = roc_auc_score(y_train, y_train_proba)

        test_acc = accuracy_score(y_test, y_test_pred)
        test_prec = precision_score(y_test, y_test_pred, zero_division=0)
        test_rec = recall_score(y_test, y_test_pred, zero_division=0)
        test_f1 = f1_score(y_test, y_test_pred, zero_division=0)
        test_auc = roc_auc_score(y_test, y_test_proba)
        cm = confusion_matrix(y_test, y_test_pred).tolist()

        best_params_clean = {k.replace('classifier__', ''): v for k, v in grid_search.best_params_.items()}

        comparison_results[model_name] = {
            'best_params': best_params_clean,
            'cv_best_score_roc_auc': round(float(grid_search.best_score_), 4),
            'train_metrics': {
                'accuracy': round(float(train_acc), 4),
                'precision': round(float(train_prec), 4),
                'recall': round(float(train_rec), 4),
                'f1_score': round(float(train_f1), 4),
                'roc_auc': round(float(train_auc), 4),
            },
            'test_metrics': {
                'accuracy': round(float(test_acc), 4),
                'precision': round(float(test_prec), 4),
                'recall': round(float(test_rec), 4),
                'f1_score': round(float(test_f1), 4),
                'roc_auc': round(float(test_auc), 4),
            },
            'confusion_matrix': cm,
            'confusion_matrix_details': {
                'true_negative': cm[0][0],
                'false_positive': cm[0][1],
                'false_negative': cm[1][0],
                'true_positive': cm[1][1]
            }
        }

        print(f"Results for {model_name}:")
        print(f"  Best Params: {best_params_clean}")
        print(f"  CV ROC-AUC: {grid_search.best_score_:.4f}")
        print(f"  Test Accuracy: {test_acc:.4f}, Test F1: {test_f1:.4f}, Test ROC-AUC: {test_auc:.4f}")
        print(f"  Confusion Matrix: TN={cm[0][0]}, FP={cm[0][1]}, FN={cm[1][0]}, TP={cm[1][1]}")

    # Select best model based on highest test ROC-AUC
    best_model_name = max(comparison_results, key=lambda k: comparison_results[k]['test_metrics']['roc_auc'])
    selected_pipeline = fitted_pipelines[best_model_name]

    print(f"\n==========================================")
    print(f"SELECTED BEST MODEL: {best_model_name}")
    print(f"==========================================")

    # Save artifacts
    pipeline_save_path = os.path.join(artifacts_dir, 'best_model_pipeline.joblib')
    joblib.dump(selected_pipeline, pipeline_save_path)
    print(f"Saved best model pipeline to: {pipeline_save_path}")

    # Save background sample (100 rows) for SHAP explainer fast loading
    shap_sample = X_train.sample(n=min(100, len(X_train)), random_state=42)
    shap_background_path = os.path.join(artifacts_dir, 'shap_background_sample.joblib')
    joblib.dump(shap_sample, shap_background_path)

    # Save comparison results
    results_save_path = os.path.join(artifacts_dir, 'model_comparison_results.json')
    comparison_meta = {
        'selected_model': best_model_name,
        'models': comparison_results
    }
    with open(results_save_path, 'w') as f:
        json.dump(comparison_meta, f, indent=2)
    print(f"Saved model comparison results to: {results_save_path}")

    # Save feature metadata
    metadata_save_path = os.path.join(artifacts_dir, 'feature_metadata.json')
    with open(metadata_save_path, 'w') as f:
        json.dump(feature_metadata, f, indent=2)
    print(f"Saved feature metadata to: {metadata_save_path}")

    print("\nTraining completed successfully!")

if __name__ == '__main__':
    run_training()
