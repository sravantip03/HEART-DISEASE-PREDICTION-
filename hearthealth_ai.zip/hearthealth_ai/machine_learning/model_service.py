"""
HeartHealth AI - Model Service
Loads the saved pipeline and provides prediction, feature metadata, and model comparison data.
"""
import os
import json
import joblib
import pandas as pd
import numpy as np

class ModelService:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ModelService, cls).__new__(cls)
            cls._instance._load_resources()
        return cls._instance

    def _load_resources(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        artifacts_dir = os.path.join(base_dir, 'artifacts')

        pipeline_path = os.path.join(artifacts_dir, 'best_model_pipeline.joblib')
        results_path = os.path.join(artifacts_dir, 'model_comparison_results.json')
        metadata_path = os.path.join(artifacts_dir, 'feature_metadata.json')
        background_path = os.path.join(artifacts_dir, 'shap_background_sample.joblib')

        self.pipeline = joblib.load(pipeline_path)

        with open(results_path, 'r') as f:
            self.comparison_results = json.load(f)

        with open(metadata_path, 'r') as f:
            self.metadata = json.load(f)

        if os.path.exists(background_path):
            self.shap_background = joblib.load(background_path)
        else:
            self.shap_background = None

        self.selected_model_name = self.comparison_results.get('selected_model', 'Gradient Boosting')
        self.core_features = self.metadata.get('core_features', [])

    def get_comparison_data(self):
        return self.comparison_results

    def get_metadata(self):
        return self.metadata

    def prepare_input_dataframe(self, input_dict):
        """
        Converts input dictionary into a pandas DataFrame matching exact feature names and dtypes.
        """
        row = {}
        for feature in self.core_features:
            val = input_dict.get(feature)
            if feature in self.metadata['numeric_features']:
                try:
                    row[feature] = [float(val)]
                except (ValueError, TypeError):
                    row[feature] = [self.metadata['numeric_stats'][feature]['median']]
            else:
                row[feature] = [str(val).strip()]
        return pd.DataFrame(row)

    def predict(self, input_dict):
        """
        Runs the trained pipeline on input data.
        Returns:
            dict with prediction (0 or 1), label, probability, probability_pct, and model_name.
        """
        df = self.prepare_input_dataframe(input_dict)
        pred_class = int(self.pipeline.predict(df)[0])
        prob_arr = self.pipeline.predict_proba(df)[0]
        # prob_arr[1] is probability of heart disease
        heart_disease_prob = float(prob_arr[1])
        heart_disease_pct = round(heart_disease_prob * 100, 2)

        result_label = "Heart Disease Indicated" if pred_class == 1 else "No Heart Disease Indicated"

        # Risk tier for educational contextualization (not clinical diagnosis)
        if heart_disease_pct >= 60.0:
            risk_tier = "High Probability"
            badge_class = "danger"
        elif heart_disease_pct >= 35.0:
            risk_tier = "Moderate Probability"
            badge_class = "warning"
        else:
            risk_tier = "Low Probability"
            badge_class = "success"

        return {
            'prediction': pred_class,
            'prediction_label': result_label,
            'probability': heart_disease_prob,
            'probability_pct': heart_disease_pct,
            'risk_tier': risk_tier,
            'badge_class': badge_class,
            'model_name': self.selected_model_name,
            'df': df
        }

# Singleton instance
model_service = ModelService()
