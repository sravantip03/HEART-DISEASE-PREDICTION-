import os
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from predictions.models import PatientAssessment
from machine_learning.model_service import model_service
from explainable_ai.shap_service import shap_service
from recommendations.recommendation_engine import RecommendationEngine
from assistant.assistant_service import assistant_service
from reports.pdf_generator import pdf_generator
from predictions.report_parser import MedicalReportParser

class HeartHealthAITestCase(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='test_clinician',
            email='test@hearthealth.ai',
            password='TestPassword123!'
        )
        self.client.login(username='test_clinician', password='TestPassword123!')

    def test_home_and_public_views(self):
        """Test public endpoints."""
        anonymous_client = Client()
        res = anonymous_client.get(reverse('core:home'))
        self.assertEqual(res.status_code, 200)

        res_edu = self.client.get(reverse('core:education'))
        self.assertEqual(res_edu.status_code, 200)

        res_xai = self.client.get(reverse('core:explainable_ai'))
        self.assertEqual(res_xai.status_code, 200)

    def test_ml_model_prediction(self):
        """Test model service prediction on sample inputs."""
        input_data = {
            'Age': 60,
            'Gender': 'Male',
            'Chest_Pain_Type': 'Typical Angina',
            'Resting_BP': 145,
            'Cholesterol': 260,
            'Fasting_Blood_Sugar': 'High',
            'Resting_ECG': 'ST-T Abnormality',
            'Max_Heart_Rate': 125,
            'Exercise_Angina': 'Yes',
            'ST_Depression': 2.5
        }
        res = model_service.predict(input_data)
        self.assertIn(res['prediction'], [0, 1])
        self.assertGreaterEqual(res['probability_pct'], 0.0)
        self.assertLessEqual(res['probability_pct'], 100.0)
        self.assertIn('df', res)

    def test_shap_explanation(self):
        """Test SHAP explainability generation and waterfall plot."""
        input_data = {
            'Age': 50,
            'Gender': 'Female',
            'Chest_Pain_Type': 'Non-anginal Pain',
            'Resting_BP': 118,
            'Cholesterol': 190,
            'Fasting_Blood_Sugar': 'Normal',
            'Resting_ECG': 'Normal',
            'Max_Heart_Rate': 165,
            'Exercise_Angina': 'No',
            'ST_Depression': 0.5
        }
        pred_res = model_service.predict(input_data)
        shap_res = shap_service.explain_prediction(pred_res['df'])
        self.assertIn('expected_value', shap_res)
        self.assertIn('contributions', shap_res)
        self.assertIn('waterfall_b64', shap_res)
        self.assertIn('importance_b64', shap_res)
        self.assertTrue(len(shap_res['contributions']) > 0)

    def test_personalized_recommendations(self):
        """Test recommendation engine output for high blood pressure and cholesterol."""
        input_data = {
            'Resting_BP': 155,
            'Cholesterol': 265,
            'Fasting_Blood_Sugar': 'High',
            'Exercise_Angina': 'Yes',
            'ST_Depression': 2.2,
            'Age': 62,
            'Max_Heart_Rate': 120
        }
        recs = RecommendationEngine.generate_recommendations(input_data, prediction_result=1)
        self.assertTrue(len(recs['priority_items']) >= 3)
        self.assertTrue(len(recs['lifestyle_advice']) >= 1)
        self.assertTrue(len(recs['doctor_questions']) > 0)

    def test_assistant_guardrails_and_triage(self):
        """Test assistant emergency triage keywords and medication restrictions."""
        # 1. Emergency
        res_emergency = assistant_service.answer_query("I have crushing chest pain radiating to left arm")
        self.assertTrue(res_emergency['is_emergency'])
        self.assertIn("EMERGENCY MEDICAL WARNING", res_emergency['response'])

        # 2. Medication refusal
        res_med = assistant_service.answer_query("Can you prescribe me statin medication?")
        self.assertFalse(res_med['is_emergency'])
        self.assertIn("Medication Safety Notice", res_med['response'])

        # 3. Contextual answer
        ctx = {'prediction_label': 'Heart Disease Indicated', 'probability_pct': 85.5, 'Resting_BP': 150}
        res_ctx = assistant_service.answer_query("Why did the model generate this prediction?", ctx)
        self.assertIn("85.5%", res_ctx['response'])

    def test_pdf_report_generation(self):
        """Test PDF generation returning valid PDF bytes."""
        assessment = PatientAssessment.objects.create(
            user=self.user,
            age=55,
            gender='Male',
            chest_pain_type='Atypical Angina',
            resting_bp=135,
            cholesterol=220,
            fasting_blood_sugar='Normal',
            resting_ecg='Normal',
            max_heart_rate=150,
            exercise_angina='No',
            st_depression=1.0,
            prediction=0,
            prediction_label='No Heart Disease Indicated',
            probability=0.25,
            probability_pct=25.0,
            risk_tier='Low Probability',
            model_name='Gradient Boosting'
        )
        pdf_bytes = pdf_generator.generate_pdf(assessment)
        self.assertTrue(pdf_bytes.startswith(b'%PDF'))

    def test_assessment_comparison_view(self):
        """Test side-by-side comparison view."""
        a1 = PatientAssessment.objects.create(
            user=self.user, age=55, gender='Male', chest_pain_type='Typical Angina',
            resting_bp=150, cholesterol=250, fasting_blood_sugar='High', resting_ecg='Normal',
            max_heart_rate=130, exercise_angina='Yes', st_depression=2.0,
            prediction=1, prediction_label='Heart Disease Indicated', probability=0.85,
            probability_pct=85.0, risk_tier='High Probability', model_name='Gradient Boosting'
        )
        a2 = PatientAssessment.objects.create(
            user=self.user, age=55, gender='Male', chest_pain_type='Non-anginal Pain',
            resting_bp=120, cholesterol=190, fasting_blood_sugar='Normal', resting_ecg='Normal',
            max_heart_rate=160, exercise_angina='No', st_depression=0.5,
            prediction=0, prediction_label='No Heart Disease Indicated', probability=0.15,
            probability_pct=15.0, risk_tier='Low Probability', model_name='Gradient Boosting'
        )
        url = reverse('history:compare') + f"?id1={a1.id}&id2={a2.id}"
        res = self.client.get(url)
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, "-30 mmHg")  # Delta in BP: 120 - 150 = -30
