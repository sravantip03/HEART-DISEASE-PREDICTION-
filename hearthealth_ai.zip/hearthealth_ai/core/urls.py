from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    path('', views.home_view, name='home'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('education/', views.education_view, name='education'),
    path('explainable-ai/', views.explainable_ai_view, name='explainable_ai'),
]
