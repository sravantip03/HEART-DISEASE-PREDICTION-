from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from predictions.models import PatientAssessment
from machine_learning.model_service import model_service

def home_view(request):
    if request.user.is_authenticated:
        return redirect('core:dashboard')
    
    metadata = model_service.get_metadata()
    comparison_data = model_service.get_comparison_data()
    
    return render(request, 'core/home.html', {
        'metadata': metadata,
        'comparison_data': comparison_data
    })

@login_required
def dashboard_view(request):
    user_assessments = PatientAssessment.objects.filter(user=request.user).order_by('-created_at')
    total_count = user_assessments.count()
    latest_assessment = user_assessments.first()
    recent_assessments = user_assessments[:5]

    high_risk_count = user_assessments.filter(prediction=1).count()
    low_risk_count = user_assessments.filter(prediction=0).count()

    comparison_data = model_service.get_comparison_data()
    metadata = model_service.get_metadata()

    return render(request, 'core/dashboard.html', {
        'total_count': total_count,
        'latest_assessment': latest_assessment,
        'recent_assessments': recent_assessments,
        'high_risk_count': high_risk_count,
        'low_risk_count': low_risk_count,
        'comparison_data': comparison_data,
        'metadata': metadata
    })

def education_view(request):
    return render(request, 'core/education.html')

def explainable_ai_view(request):
    latest_assessment = None
    if request.user.is_authenticated:
        latest_assessment = PatientAssessment.objects.filter(user=request.user).order_by('-created_at').first()

    comparison_data = model_service.get_comparison_data()
    return render(request, 'core/explainable_ai.html', {
        'latest_assessment': latest_assessment,
        'comparison_data': comparison_data
    })
