# Core app models
