from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.dateparse import parse_date
from predictions.models import PatientAssessment

@login_required
def history_list_view(request):
    assessments = PatientAssessment.objects.filter(user=request.user)

    # Search & Filtering
    filter_result = request.GET.get('result', '')
    start_date_str = request.GET.get('start_date', '')
    end_date_str = request.GET.get('end_date', '')

    if filter_result in ['0', '1']:
        assessments = assessments.filter(prediction=int(filter_result))

    if start_date_str:
        s_date = parse_date(start_date_str)
        if s_date:
            assessments = assessments.filter(created_at__date__gte=s_date)

    if end_date_str:
        e_date = parse_date(end_date_str)
        if e_date:
            assessments = assessments.filter(created_at__date__lte=e_date)

    return render(request, 'history/history_list.html', {
        'assessments': assessments,
        'filter_result': filter_result,
        'start_date': start_date_str,
        'end_date': end_date_str,
        'total_count': assessments.count()
    })

@login_required
def delete_assessment_view(request, assessment_id):
    assessment = get_object_or_404(PatientAssessment, id=assessment_id, user=request.user)
    if request.method == 'POST':
        assessment.delete()
        messages.success(request, f"Assessment #{assessment_id} was deleted successfully.")
    return redirect('history:history_list')

@login_required
def compare_assessments_view(request):
    user_assessments = PatientAssessment.objects.filter(user=request.user).order_by('-created_at')

    id1 = request.GET.get('id1')
    id2 = request.GET.get('id2')

    assessment1 = None
    assessment2 = None
    comparison_table = []

    if id1 and id2:
        try:
            assessment1 = user_assessments.get(id=int(id1))
            assessment2 = user_assessments.get(id=int(id2))

            # Build parameter comparison with delta indicators
            params = [
                ('Age', 'age', 'years', True),
                ('Resting Blood Pressure', 'resting_bp', 'mmHg', True),
                ('Total Cholesterol', 'cholesterol', 'mg/dL', True),
                ('Maximum Heart Rate', 'max_heart_rate', 'bpm', True),
                ('ST Depression', 'st_depression', 'mm', True),
                ('Gender', 'gender', '', False),
                ('Chest Pain Type', 'chest_pain_type', '', False),
                ('Fasting Blood Sugar', 'fasting_blood_sugar', '', False),
                ('Resting ECG', 'resting_ecg', '', False),
                ('Exercise Angina', 'exercise_angina', '', False),
            ]

            for label, attr, unit, is_numeric in params:
                v1 = getattr(assessment1, attr)
                v2 = getattr(assessment2, attr)
                delta_str = ""
                delta_class = ""

                if is_numeric:
                    diff = v2 - v1
                    diff_fmt = f"{diff:.1f}" if isinstance(diff, float) else f"{diff}"
                    if diff > 0:
                        delta_str = f"+{diff_fmt} {unit}".strip()
                        # In BP, cholesterol, ST depression, increase is worse (red), in Max HR increase can be good
                        delta_class = "text-danger" if attr != 'max_heart_rate' else "text-success"
                    elif diff < 0:
                        delta_str = f"{diff_fmt} {unit}".strip()
                        delta_class = "text-success" if attr != 'max_heart_rate' else "text-danger"
                    else:
                        delta_str = "No Change"
                        delta_class = "text-muted"
                else:
                    if v1 != v2:
                        delta_str = "Changed"
                        delta_class = "text-primary"
                    else:
                        delta_str = "Identical"
                        delta_class = "text-muted"

                comparison_table.append({
                    'label': label,
                    'val1': f"{v1} {unit}".strip(),
                    'val2': f"{v2} {unit}".strip(),
                    'delta': delta_str,
                    'delta_class': delta_class
                })

        except Exception as e:
            messages.error(request, f"Error comparing assessments: {e}")

    return render(request, 'history/compare.html', {
        'user_assessments': user_assessments,
        'assessment1': assessment1,
        'assessment2': assessment2,
        'comparison_table': comparison_table,
        'selected_id1': id1,
        'selected_id2': id2
    })
