from django.urls import path
from . import views

app_name = 'history'

urlpatterns = [
    path('', views.history_list_view, name='history_list'),
    path('compare/', views.compare_assessments_view, name='compare'),
    path('delete/<int:assessment_id>/', views.delete_assessment_view, name='delete_assessment'),
]
