"""
HeartHealth AI - Medical Report Parser
Extracts readable text from PDF and image files, identifies clinical health parameters
using robust pattern matching, and extracts values ONLY when clearly available.
"""
import re
import os
import pypdf
import pdfplumber
from PIL import Image

try:
    import winocr
    WINOCR_AVAILABLE = True
except ImportError:
    WINOCR_AVAILABLE = False

class MedicalReportParser:
    @staticmethod
    def extract_text_from_pdf(file_path):
        """Extracts text using pdfplumber with fallback to pypdf."""
        extracted_text = ""
        try:
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    txt = page.extract_text()
                    if txt:
                        extracted_text += txt + "\n"
        except Exception:
            pass

        if not extracted_text.strip():
            try:
                reader = pypdf.PdfReader(file_path)
                for page in reader.pages:
                    txt = page.extract_text()
                    if txt:
                        extracted_text += txt + "\n"
            except Exception:
                pass

        return extracted_text.strip()

    @staticmethod
    def extract_text_from_image(file_path):
        """Extracts text using Windows native OCR (winocr) or image inspection."""
        if not WINOCR_AVAILABLE:
            return ""

        try:
            # winocr.recognize_pil extracts words from PIL image
            img = Image.open(file_path)
            result = winocr.recognize_pil_sync(img, lang="en-US")
            lines = []
            if result and 'lines' in result:
                for line in result['lines']:
                    lines.append(line.get('text', ''))
            return "\n".join(lines).strip()
        except Exception as e:
            print(f"Image OCR error: {e}")
            return ""

    @classmethod
    def parse_report(cls, file_path):
        """
        Parses uploaded report and returns extracted parameters dictionary,
        the raw text, and detected confidence. Does NOT fabricate missing values.
        """
        ext = os.path.splitext(file_path)[1].lower()
        if ext == '.pdf':
            raw_text = cls.extract_text_from_pdf(file_path)
        elif ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']:
            raw_text = cls.extract_text_from_image(file_path)
        else:
            return {"error": "Unsupported file format. Please upload PDF, PNG, or JPG."}, ""

        if not raw_text:
            return {"warning": "No readable text could be extracted from the file."}, ""

        extracted = {}

        # 1. Age (18 - 99)
        age_patterns = [
            r'(?:Age|AGE)\s*[:=\-]?\s*(\d{2})\b',
            r'\b(\d{2})\s*(?:years? old|yo|yrs)\b'
        ]
        for pat in age_patterns:
            m = re.search(pat, raw_text, re.IGNORECASE)
            if m:
                val = int(m.group(1))
                if 18 <= val <= 100:
                    extracted['Age'] = val
                    break

        # 2. Gender
        gender_m = re.search(r'(?:Gender|Sex)\s*[:=\-]?\s*(Male|Female|M|F)\b', raw_text, re.IGNORECASE)
        if gender_m:
            g = gender_m.group(1).upper()
            extracted['Gender'] = "Male" if g in ['M', 'MALE'] else "Female"

        # 3. Resting Blood Pressure (Systolic BP, 80-220 mmHg)
        bp_patterns = [
            r'(?:Blood Pressure|Resting BP|BP)\s*[:=\-]?\s*(\d{2,3})\s*(?:/\s*(\d{2,3}))?\s*(?:mmHg)?',
            r'\b(\d{2,3})\s*/\s*(\d{2,3})\s*mmHg\b'
        ]
        for pat in bp_patterns:
            m = re.search(pat, raw_text, re.IGNORECASE)
            if m:
                sys_val = int(m.group(1))
                if 80 <= sys_val <= 240:
                    extracted['Resting_BP'] = sys_val
                    break

        # 4. Total Cholesterol (100 - 400 mg/dL)
        chol_patterns = [
            r'(?:Total\s+)?Cholesterol\s*[:=\-]?\s*(\d{2,3})\s*(?:mg/dL)?',
            r'Lipid\s*Panel.*?Cholesterol\s*[:=\-]?\s*(\d{2,3})'
        ]
        for pat in chol_patterns:
            m = re.search(pat, raw_text, re.IGNORECASE | re.DOTALL)
            if m:
                c_val = int(m.group(1))
                if 100 <= c_val <= 450:
                    extracted['Cholesterol'] = c_val
                    break

        # 5. Fasting Blood Sugar (Normal vs High, or numeric mg/dL)
        fbs_num_m = re.search(r'(?:Fasting Blood Sugar|FBS|Fasting Glucose)\s*[:=\-]?\s*(\d{2,3})\s*(?:mg/dL)?', raw_text, re.IGNORECASE)
        if fbs_num_m:
            fbs_val = int(fbs_num_m.group(1))
            extracted['Fasting_Blood_Sugar'] = "High" if fbs_val >= 120 else "Normal"
            extracted['Fasting_Blood_Sugar_numeric'] = fbs_val
        else:
            fbs_text_m = re.search(r'(?:Fasting Blood Sugar|FBS|Glucose)\s*[:=\-]?\s*(Normal|High|Elevated)', raw_text, re.IGNORECASE)
            if fbs_text_m:
                v = fbs_text_m.group(1).capitalize()
                extracted['Fasting_Blood_Sugar'] = "High" if v in ["High", "Elevated"] else "Normal"

        # 6. Maximum Heart Rate (60 - 220 bpm)
        hr_patterns = [
            r'(?:Max Heart Rate|Maximum Heart Rate|Peak HR|Max HR)\s*[:=\-]?\s*(\d{2,3})\s*(?:bpm)?',
            r'(?:Heart Rate|Pulse|HR)\s*[:=\-]?\s*(\d{2,3})\s*bpm'
        ]
        for pat in hr_patterns:
            m = re.search(pat, raw_text, re.IGNORECASE)
            if m:
                hr_val = int(m.group(1))
                if 60 <= hr_val <= 220:
                    extracted['Max_Heart_Rate'] = hr_val
                    break

        # 7. Exercise Induced Angina (Yes / No)
        angina_m = re.search(r'(?:Exercise[- ]induced Angina|Exercise Angina|Angina with exertion)\s*[:=\-]?\s*(Yes|No|Positive|Negative|Present|Absent)', raw_text, re.IGNORECASE)
        if angina_m:
            ans = angina_m.group(1).lower()
            extracted['Exercise_Angina'] = "Yes" if ans in ['yes', 'positive', 'present'] else "No"

        # 8. ST Depression (0.0 - 6.0 mm)
        st_m = re.search(r'(?:ST[- ]Depression|ST segment depression|ST Dep)\s*[:=\-]?\s*(\d+(?:\.\d+)?)\s*(?:mm)?', raw_text, re.IGNORECASE)
        if st_m:
            st_val = float(st_m.group(1))
            if 0.0 <= st_val <= 8.0:
                extracted['ST_Depression'] = st_val

        # 9. Chest Pain Type
        if re.search(r'Typical\s+Angina', raw_text, re.IGNORECASE):
            extracted['Chest_Pain_Type'] = 'Typical Angina'
        elif re.search(r'Atypical\s+Angina', raw_text, re.IGNORECASE):
            extracted['Chest_Pain_Type'] = 'Atypical Angina'
        elif re.search(r'Non[- ]anginal', raw_text, re.IGNORECASE):
            extracted['Chest_Pain_Type'] = 'Non-anginal Pain'
        elif re.search(r'Asymptomatic', raw_text, re.IGNORECASE):
            extracted['Chest_Pain_Type'] = 'Asymptomatic'

        # 10. Resting ECG
        if re.search(r'Left Ventricular Hypertrophy|LVH', raw_text, re.IGNORECASE):
            extracted['Resting_ECG'] = 'Left Ventricular Hypertrophy'
        elif re.search(r'ST[- ]T(?:\s+Abnormality|\s+wave changes)', raw_text, re.IGNORECASE):
            extracted['Resting_ECG'] = 'ST-T Abnormality'
        elif re.search(r'Normal ECG|Normal Resting ECG|ECG:\s*Normal', raw_text, re.IGNORECASE):
            extracted['Resting_ECG'] = 'Normal'

        return extracted, raw_text
