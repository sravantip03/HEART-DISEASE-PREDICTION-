from django import forms
from .models import PatientAssessment

class PatientAssessmentForm(forms.ModelForm):
    class Meta:
        model = PatientAssessment
        fields = [
            'age', 'gender', 'chest_pain_type', 'resting_bp', 'cholesterol',
            'fasting_blood_sugar', 'resting_ecg', 'max_heart_rate',
            'exercise_angina', 'st_depression'
        ]
        widgets = {
            'age': forms.NumberInput(attrs={'class': 'form-control', 'min': 18, 'max': 100, 'placeholder': 'e.g. 54'}),
            'gender': forms.Select(attrs={'class': 'form-select'}),
            'chest_pain_type': forms.Select(attrs={'class': 'form-select'}),
            'resting_bp': forms.NumberInput(attrs={'class': 'form-control', 'min': 80, 'max': 220, 'placeholder': 'e.g. 120 (mmHg)'}),
            'cholesterol': forms.NumberInput(attrs={'class': 'form-control', 'min': 100, 'max': 450, 'placeholder': 'e.g. 195 (mg/dL)'}),
            'fasting_blood_sugar': forms.Select(attrs={'class': 'form-select'}),
            'resting_ecg': forms.Select(attrs={'class': 'form-select'}),
            'max_heart_rate': forms.NumberInput(attrs={'class': 'form-control', 'min': 60, 'max': 220, 'placeholder': 'e.g. 150 (bpm)'}),
            'exercise_angina': forms.Select(attrs={'class': 'form-select'}),
            'st_depression': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'min': 0.0, 'max': 6.0, 'placeholder': 'e.g. 1.2 (mm)'}),
        }

    def clean_age(self):
        age = self.cleaned_data.get('age')
        if age is None or age < 18 or age > 105:
            raise forms.ValidationError("Please enter an age between 18 and 105.")
        return age

    def clean_resting_bp(self):
        bp = self.cleaned_data.get('resting_bp')
        if bp is None or bp < 70 or bp > 260:
            raise forms.ValidationError("Resting blood pressure must be between 70 and 260 mmHg.")
        return bp

    def clean_cholesterol(self):
        c = self.cleaned_data.get('cholesterol')
        if c is None or c < 80 or c > 550:
            raise forms.ValidationError("Total cholesterol must be between 80 and 550 mg/dL.")
        return c

    def clean_max_heart_rate(self):
        hr = self.cleaned_data.get('max_heart_rate')
        if hr is None or hr < 50 or hr > 240:
            raise forms.ValidationError("Maximum heart rate must be between 50 and 240 bpm.")
        return hr

    def clean_st_depression(self):
        st = self.cleaned_data.get('st_depression')
        if st is None or st < 0.0 or st > 8.0:
            raise forms.ValidationError("ST depression must be between 0.0 and 8.0 mm.")
        return st

class MedicalReportUploadForm(forms.Form):
    report_file = forms.FileField(
        widget=forms.FileInput(attrs={'class': 'form-control', 'accept': '.pdf,.png,.jpg,.jpeg'}),
        help_text="Supported formats: PDF, PNG, JPG, JPEG (Max file size: 10MB)"
    )

    def clean_report_file(self):
        f = self.cleaned_data.get('report_file')
        if f:
            if f.size > 10 * 1024 * 1024:
                raise forms.ValidationError("File size exceeds 10MB limit.")
            ext = f.name.split('.')[-1].lower()
            if ext not in ['pdf', 'png', 'jpg', 'jpeg']:
                raise forms.ValidationError("Unsupported file extension. Allowed: PDF, PNG, JPG, JPEG.")
        return f
