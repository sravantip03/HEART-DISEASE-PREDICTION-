from django.db import models
from django.contrib.auth.models import User

class PatientAssessment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assessments', null=True, blank=True)
    
    # 10 Core Health Parameters
    age = models.PositiveIntegerField(help_text="Age in years (18-100)")
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female')])
    chest_pain_type = models.CharField(
        max_length=30,
        choices=[
            ('Typical Angina', 'Typical Angina'),
            ('Atypical Angina', 'Atypical Angina'),
            ('Non-anginal Pain', 'Non-anginal Pain'),
            ('Asymptomatic', 'Asymptomatic')
        ]
    )
    resting_bp = models.PositiveIntegerField(help_text="Resting blood pressure in mmHg (80-220)")
    cholesterol = models.PositiveIntegerField(help_text="Serum cholesterol in mg/dL (100-450)")
    fasting_blood_sugar = models.CharField(
        max_length=10,
        choices=[('Normal', 'Normal (< 120 mg/dL)'), ('High', 'High (>= 120 mg/dL)')]
    )
    resting_ecg = models.CharField(
        max_length=40,
        choices=[
            ('Normal', 'Normal'),
            ('ST-T Abnormality', 'ST-T Wave Abnormality'),
            ('Left Ventricular Hypertrophy', 'Left Ventricular Hypertrophy')
        ]
    )
    max_heart_rate = models.PositiveIntegerField(help_text="Maximum heart rate achieved in bpm (60-220)")
    exercise_angina = models.CharField(max_length=10, choices=[('Yes', 'Yes'), ('No', 'No')])
    st_depression = models.FloatField(help_text="ST depression induced by exercise relative to rest in mm (0.0-6.0)")

    # Explicit handling of ST_Slope
    st_slope = models.CharField(
        max_length=50,
        default="Not Available in Dataset",
        help_text="ST Slope is not present in the supplied dataset and was excluded from model training."
    )

    # Medical report upload tracking
    uploaded_report_filename = models.CharField(max_length=255, blank=True)

    # Model Prediction Results
    prediction = models.IntegerField(choices=[(0, 'No Heart Disease'), (1, 'Heart Disease')])
    prediction_label = models.CharField(max_length=50)
    probability = models.FloatField()
    probability_pct = models.FloatField()
    risk_tier = models.CharField(max_length=30)
    model_name = models.CharField(max_length=50)

    # SHAP Explanations Cache
    shap_data = models.JSONField(default=dict, blank=True)

    # Timestamp
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        user_str = self.user.username if self.user else "Anonymous"
        return f"Assessment #{self.id} - {user_str} ({self.created_at.strftime('%Y-%m-%d %H:%M')})"

    def to_input_dict(self):
        """Converts model fields to format required by model_service."""
        return {
            'Age': self.age,
            'Gender': self.gender,
            'Chest_Pain_Type': self.chest_pain_type,
            'Resting_BP': self.resting_bp,
            'Cholesterol': self.cholesterol,
            'Fasting_Blood_Sugar': self.fasting_blood_sugar,
            'Resting_ECG': self.resting_ecg,
            'Max_Heart_Rate': self.max_heart_rate,
            'Exercise_Angina': self.exercise_angina,
            'ST_Depression': self.st_depression
        }
