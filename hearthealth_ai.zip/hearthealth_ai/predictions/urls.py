from django.urls import path
from . import views

app_name = 'predictions'

urlpatterns = [
    path('predict/', views.predict_form_view, name='predict'),
    path('upload-report/', views.upload_report_ajax_view, name='upload_report'),
    path('result/<int:assessment_id>/', views.result_detail_view, name='result_detail'),
    path('download-pdf/<int:assessment_id>/', views.download_pdf_view, name='download_pdf'),
]
