import os
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile

from .models import PatientAssessment
from .forms import PatientAssessmentForm, MedicalReportUploadForm
from .report_parser import MedicalReportParser
from machine_learning.model_service import model_service
from explainable_ai.shap_service import shap_service
from recommendations.recommendation_engine import RecommendationEngine
from reports.pdf_generator import pdf_generator

@login_required
def predict_form_view(request):
    upload_form = MedicalReportUploadForm()

    if request.method == 'POST':
        form = PatientAssessmentForm(request.POST)
        if form.is_valid():
            assessment = form.save(commit=False)
            assessment.user = request.user
            assessment.uploaded_report_filename = request.POST.get('uploaded_report_filename', '')

            # Convert to dictionary for model prediction
            input_dict = {
                'Age': assessment.age,
                'Gender': assessment.gender,
                'Chest_Pain_Type': assessment.chest_pain_type,
                'Resting_BP': assessment.resting_bp,
                'Cholesterol': assessment.cholesterol,
                'Fasting_Blood_Sugar': assessment.fasting_blood_sugar,
                'Resting_ECG': assessment.resting_ecg,
                'Max_Heart_Rate': assessment.max_heart_rate,
                'Exercise_Angina': assessment.exercise_angina,
                'ST_Depression': assessment.st_depression
            }

            # 1. Run ML Prediction
            pred_result = model_service.predict(input_dict)
            assessment.prediction = pred_result['prediction']
            assessment.prediction_label = pred_result['prediction_label']
            assessment.probability = pred_result['probability']
            assessment.probability_pct = pred_result['probability_pct']
            assessment.risk_tier = pred_result['risk_tier']
            assessment.model_name = pred_result['model_name']

            # 2. Run SHAP Explainable AI Analysis
            try:
                shap_res = shap_service.explain_prediction(pred_result['df'])
                # Store lightweight JSON data in DB
                assessment.shap_data = {
                    'expected_value': shap_res['expected_value'],
                    'contributions': shap_res['contributions'],
                    'narrative': shap_res['narrative'],
                    'waterfall_b64': shap_res['waterfall_b64'],
                    'importance_b64': shap_res['importance_b64']
                }
            except Exception as e:
                print(f"SHAP explanation error: {e}")
                assessment.shap_data = {'error': str(e)}

            assessment.save()
            messages.success(request, "Assessment calculated successfully using the trained machine learning pipeline.")
            return redirect('predictions:result_detail', assessment_id=assessment.id)
    else:
        # Prepopulate with profile gender if present
        initial_data = {}
        if hasattr(request.user, 'profile'):
            initial_data['gender'] = request.user.profile.gender
        form = PatientAssessmentForm(initial=initial_data)

    metadata = model_service.get_metadata()

    return render(request, 'predictions/predict_form.html', {
        'form': form,
        'upload_form': upload_form,
        'metadata': metadata
    })

@login_required
def upload_report_ajax_view(request):
    """Handles report upload, text extraction, parameter parsing, and returns JSON."""
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'POST method required.'}, status=405)

    form = MedicalReportUploadForm(request.POST, request.FILES)
    if not form.is_valid():
        errors = [f"{field}: {err[0]}" for field, err in form.errors.items()]
        return JsonResponse({'success': False, 'error': " ".join(errors)}, status=400)

    uploaded_file = request.FILES['report_file']
    filename = uploaded_file.name

    # Save to media/temp_reports
    save_path = os.path.join(settings.MEDIA_ROOT, 'temp_reports', filename)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'wb+') as destination:
        for chunk in uploaded_file.chunks():
            destination.write(chunk)

    try:
        extracted_params, raw_text = MedicalReportParser.parse_report(save_path)
        if isinstance(extracted_params, dict) and "error" in extracted_params:
            return JsonResponse({'success': False, 'error': extracted_params['error']}, status=400)

        return JsonResponse({
            'success': True,
            'filename': filename,
            'extracted': extracted_params,
            'detected_count': len(extracted_params),
            'raw_text_snippet': raw_text[:500] if raw_text else "No extractable text"
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': f"Failed to parse report: {str(e)}"}, status=500)

@login_required
def result_detail_view(request, assessment_id):
    assessment = get_object_or_404(PatientAssessment, id=assessment_id, user=request.user)

    # Generate tailored recommendations
    recommendations = RecommendationEngine.generate_recommendations(
        assessment.to_input_dict(), assessment.prediction
    )

    comparison_data = model_service.get_comparison_data()

    return render(request, 'predictions/result_detail.html', {
        'assessment': assessment,
        'shap_data': assessment.shap_data,
        'recommendations': recommendations,
        'comparison_data': comparison_data
    })

@login_required
def download_pdf_view(request, assessment_id):
    assessment = get_object_or_404(PatientAssessment, id=assessment_id, user=request.user)
    recommendations = RecommendationEngine.generate_recommendations(
        assessment.to_input_dict(), assessment.prediction
    )

    pdf_bytes = pdf_generator.generate_pdf(assessment, assessment.shap_data, recommendations)
    response = HttpResponse(pdf_bytes, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="HeartHealth_Report_{assessment.id}.pdf"'
    return response
