from django.urls import path
from . import views

app_name = 'assistant'

urlpatterns = [
    path('', views.assistant_chat_view, name='chat'),
    path('api/send/', views.assistant_message_api, name='send_message'),
]
