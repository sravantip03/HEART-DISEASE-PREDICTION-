# Assistant app models
