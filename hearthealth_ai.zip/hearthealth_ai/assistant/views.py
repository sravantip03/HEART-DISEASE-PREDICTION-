import json
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from predictions.models import PatientAssessment
from .assistant_service import assistant_service

@login_required
def assistant_chat_view(request):
    assessment_id = request.GET.get('assessment_id')
    active_assessment = None
    if assessment_id:
        active_assessment = PatientAssessment.objects.filter(id=assessment_id, user=request.user).first()
    if not active_assessment:
        active_assessment = PatientAssessment.objects.filter(user=request.user).first()

    recent_assessments = PatientAssessment.objects.filter(user=request.user).order_by('-created_at')[:5]

    return render(request, 'assistant/chat.html', {
        'active_assessment': active_assessment,
        'recent_assessments': recent_assessments
    })

@login_required
def assistant_message_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
        user_message = data.get('message', '').strip()
        assessment_id = data.get('assessment_id')

        if not user_message:
            return JsonResponse({'error': 'Message cannot be empty'}, status=400)

        context = {}
        if assessment_id:
            assessment = PatientAssessment.objects.filter(id=assessment_id, user=request.user).first()
            if assessment:
                context = {
                    'prediction_label': assessment.prediction_label,
                    'probability_pct': assessment.probability_pct,
                    'risk_tier': assessment.risk_tier,
                    'Age': assessment.age,
                    'Gender': assessment.gender,
                    'Resting_BP': assessment.resting_bp,
                    'Cholesterol': assessment.cholesterol,
                    'Fasting_Blood_Sugar': assessment.fasting_blood_sugar,
                    'Chest_Pain_Type': assessment.chest_pain_type,
                    'Resting_ECG': assessment.resting_ecg,
                    'Max_Heart_Rate': assessment.max_heart_rate,
                    'Exercise_Angina': assessment.exercise_angina,
                    'ST_Depression': assessment.st_depression
                }

        reply = assistant_service.answer_query(user_message, assessment_context=context)
        return JsonResponse(reply)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
