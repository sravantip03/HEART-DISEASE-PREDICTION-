"""
HeartHealth AI - AI Health Assessment Assistant Service
Context-aware educational conversational assistant with medical guardrails.
Supports built-in educational reasoning engine with optional external LLM fallback.
"""
import os
import re

SYSTEM_DISCLAIMER = (
    "Disclaimer: HeartHealth AI Assistant provides educational information only. "
    "It is not a doctor, cannot diagnose diseases, and cannot prescribe or alter medications. "
    "If you experience severe chest pain, shortness of breath, pain radiating to your arm or jaw, "
    "or sudden dizziness, seek emergency medical care (dial 911/112) immediately."
)

class AssistantService:
    @staticmethod
    def answer_query(user_message, assessment_context=None):
        """
        Answers user inquiries using the current patient assessment context.
        Enforces strict safety, triage, and educational guardrails.
        """
        user_message_clean = user_message.strip()
        msg_lower = user_message_clean.lower()

        # 1. Immediate Emergency Triage Check
        emergency_keywords = [
            'crushing', 'radiating', 'left arm', 'jaw pain',
            'cannot breathe', 'difficulty breathing', 'shortness of breath',
            'severe chest', 'heart attack', 'call ambulance', 'fainting', 'collapsed'
        ]
        if any(k in msg_lower for k in emergency_keywords):
            return {
                'response': (
                    "🚨 **EMERGENCY MEDICAL WARNING**\n\n"
                    "The symptoms you describe may indicate an acute cardiovascular emergency, "
                    "such as myocardial infarction (heart attack) or unstable angina.\n\n"
                    "**Immediate Action Required:**\n"
                    "- Please stop reading, sit down safely, and **call your local emergency number (911, 112, or local EMS) immediately**.\n"
                    "- Do not attempt to drive yourself to the hospital.\n"
                    "- Notify someone near you right away.\n\n"
                    "This application cannot provide emergency medical intervention."
                ),
                'is_emergency': True
            }

        # 2. Medication / Prescription Guardrail
        med_keywords = ['prescribe', 'take aspirin', 'take statin', 'stop taking medication', 'change dosage', 'which medicine']
        if any(k in msg_lower for k in med_keywords):
            return {
                'response': (
                    "⚠️ **Medication Safety Notice**\n\n"
                    "I cannot prescribe, recommend, or advise adjustments to any pharmaceutical medications. "
                    "Medications such as statins, ACE inhibitors, beta-blockers, or blood thinners must be prescribed "
                    "exclusively by a licensed physician after reviewing your complete medical history, liver function, "
                    "and kidney panels.\n\n"
                    "Please bring your HeartHealth AI assessment summary to your physician to discuss whether any "
                    "pharmacological intervention is appropriate for you."
                ),
                'is_emergency': False
            }

        # 3. Contextual Responses using Assessment Data
        ctx = assessment_context or {}
        pred_label = ctx.get('prediction_label', 'Assessment Not Recorded')
        prob_pct = ctx.get('probability_pct', 'N/A')
        rbp = ctx.get('Resting_BP', 'N/A')
        chol = ctx.get('Cholesterol', 'N/A')
        fbs = ctx.get('Fasting_Blood_Sugar', 'N/A')
        cpt = ctx.get('Chest_Pain_Type', 'N/A')
        ecg = ctx.get('Resting_ECG', 'N/A')
        max_hr = ctx.get('Max_Heart_Rate', 'N/A')
        angina = ctx.get('Exercise_Angina', 'N/A')
        st_dep = ctx.get('ST_Depression', 'N/A')
        age = ctx.get('Age', 'N/A')
        gender = ctx.get('Gender', 'N/A')

        # Check intent
        # A: Explain prediction / model output
        if any(k in msg_lower for k in ['why', 'explain prediction', 'what does this mean', 'result', 'prediction', 'risk']):
            return {
                'response': (
                    f"### Understanding Your Prediction Result\n\n"
                    f"- **Model Output:** {pred_label}\n"
                    f"- **Calculated Model Probability:** {prob_pct}%\n\n"
                    f"**How the Model Arrived at this Output:**\n"
                    f"The machine learning model evaluated your 10 clinical parameters against pattern data from 10,000 patient records. "
                    f"The most significant contributors to your score were:\n"
                    f"- **Resting Blood Pressure:** {rbp} mmHg\n"
                    f"- **Cholesterol:** {chol} mg/dL\n"
                    f"- **Chest Pain Category:** {cpt}\n"
                    f"- **ST Depression on ECG:** {st_dep} mm\n"
                    f"- **Exercise-Induced Angina:** {angina}\n\n"
                    f"*Note: This probability reflects pattern similarity in the training dataset and is NOT a medical diagnosis.*"
                ),
                'is_emergency': False
            }

        # B: Explain SHAP / Chart
        if any(k in msg_lower for k in ['shap', 'waterfall', 'chart', 'graph', 'feature contribution', 'bar chart']):
            return {
                'response': (
                    "### How to Read Your Explainable AI (SHAP) Visualizations\n\n"
                    "SHAP (SHapley Additive exPlanations) is a game-theoretic approach that explains how each individual health parameter pushed your prediction up or down:\n\n"
                    "- 🔴 **Red Bars / Positive Values:** Push the model toward predicting potential heart disease (elevating the likelihood).\n"
                    "- 🔵 **Navy/Blue Bars / Negative Values:** Push the model away from heart disease (acting as protective indicators).\n"
                    "- **Waterfall Chart:** Starts at the baseline average rate across all patients and adds each of your parameter impacts step-by-step until reaching your final score.\n\n"
                    "This ensures the model is transparent and never acts as a 'black box'."
                ),
                'is_emergency': False
            }

        # C: Blood Pressure inquiries
        if any(k in msg_lower for k in ['blood pressure', 'bp', 'systolic', 'hypertension']):
            return {
                'response': (
                    f"### Blood Pressure & Heart Health\n\n"
                    f"Your submitted resting blood pressure is **{rbp} mmHg**.\n\n"
                    f"**Clinical Classifications (AHA Guidelines):**\n"
                    f"- **Normal:** Under 120 mmHg systolic\n"
                    f"- **Elevated:** 120–129 mmHg\n"
                    f"- **Stage 1 Hypertension:** 130–139 mmHg\n"
                    f"- **Stage 2 Hypertension:** 140 mmHg or higher\n\n"
                    f"When blood pressure remains high, arteries experience continuous mechanical shear stress, "
                    f"leading to micro-tears in arterial walls where cholesterol easily deposits, forming plaques."
                ),
                'is_emergency': False
            }

        # D: Cholesterol inquiries
        if any(k in msg_lower for k in ['cholesterol', 'ldl', 'hdl', 'lipid', 'triglyceride']):
            return {
                'response': (
                    f"### Cholesterol & Plaque Formation\n\n"
                    f"Your submitted total cholesterol level is **{chol} mg/dL**.\n\n"
                    f"- **Desirable:** Under 200 mg/dL\n"
                    f"- **Borderline High:** 200–239 mg/dL\n"
                    f"- **High:** 240 mg/dL and above\n\n"
                    f"Cholesterol is an essential lipid, but excess LDL particles penetrate endothelial walls and oxidize, "
                    f"attracting macrophages and creating atherosclerotic plaques that restrict blood flow to your myocardium."
                ),
                'is_emergency': False
            }

        # E: ECG / ST Depression
        if any(k in msg_lower for k in ['ecg', 'electrocardiogram', 'st depression', 'st slope', 'lvh', 'hypertrophy']):
            return {
                'response': (
                    f"### Electrocardiogram (ECG) & ST Depression\n\n"
                    f"- **Resting ECG:** {ecg}\n"
                    f"- **ST Depression:** {st_dep} mm\n\n"
                    f"**What is ST Depression?**\n"
                    f"In an ECG waveform, the ST segment represents the period between ventricular depolarization and repolarization. "
                    f"When cardiac muscle receives insufficient oxygen (ischemia), the ST segment often dips downward below the baseline (isoelectric line). "
                    f"Depression of 1.0 mm or more during exertion or at rest is a key clinical sign of coronary insufficiency."
                ),
                'is_emergency': False
            }

        # F: Heart Rate inquiries
        if any(k in msg_lower for k in ['heart rate', 'max hr', 'pulse', 'bpm', 'tachycardia']):
            return {
                'response': (
                    f"### Maximum Heart Rate & Cardiovascular Capacity\n\n"
                    f"Your recorded peak heart rate was **{max_hr} bpm** (Age: {age}).\n\n"
                    f"The standard age-predicted maximum heart rate is approximately `220 - Age`. "
                    f"For a {age}-year-old individual, the theoretical maximum is approximately `{220 - int(age) if str(age).isdigit() else 'N/A'} bpm`.\n\n"
                    f"Reaching 85% or more of your predicted maximum during exercise is an indicator of strong cardiovascular reserve."
                ),
                'is_emergency': False
            }

        # G: Chest Pain Types
        if any(k in msg_lower for k in ['chest pain', 'angina', 'atypical', 'non-anginal']):
            return {
                'response': (
                    f"### Understanding Chest Pain Types\n\n"
                    f"Your submitted category is: **{cpt}**.\n\n"
                    f"- **Typical Angina:** Sub-sternal pressure, squeezing, or heaviness brought on by physical exertion or stress, relieved by rest or nitroglycerin.\n"
                    "- **Atypical Angina:** Discomfort meeting some but not all classic features; common in women and older adults.\n"
                    "- **Non-anginal Pain:** Pain related to musculoskeletal strain, esophageal reflux, or pulmonary causes rather than ischemic cardiac tissue.\n"
                    "- **Asymptomatic:** Absence of chest discomfort; note that ischemia can sometimes occur without pain (silent ischemia)."
                ),
                'is_emergency': False
            }

        # H: General health / Default guidance
        return {
            'response': (
                f"### Heart Health Educational Guidance\n\n"
                f"Thank you for your question. Based on your current profile (Age: {age}, Gender: {gender}, Prediction: {pred_label}):\n\n"
                f"- **Cardiovascular Wellness Pillars:** Consistent aerobic activity (at least 150 minutes of moderate activity weekly), "
                f"a heart-healthy Mediterranean or DASH dietary pattern, stress mitigation, and regular blood pressure monitoring.\n"
                f"- **What to Do Next:** You can download your comprehensive PDF summary from the Prediction Results page to share with your primary care physician or cardiologist."
            ),
            'is_emergency': False
        }

assistant_service = AssistantService()
