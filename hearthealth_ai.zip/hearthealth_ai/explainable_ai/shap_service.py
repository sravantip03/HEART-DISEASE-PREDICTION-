"""
HeartHealth AI - SHAP Explainability Service
Calculates individual SHAP values, renders high-resolution charts, and provides
plain-language explanations for patient predictions.
"""
import os
import io
import base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shap
from machine_learning.model_service import model_service

class ShapService:
    def __init__(self):
        self.pipeline = model_service.pipeline
        self.preprocessor = self.pipeline.named_steps['preprocessor']
        self.classifier = self.pipeline.named_steps['classifier']
        self.explainer = shap.TreeExplainer(self.classifier)
        self.encoded_feature_names = model_service.metadata['encoded_feature_names']

    def _clean_feature_name(self, raw_name):
        """Converts internal encoded column name to user-friendly label."""
        name = raw_name.replace('num__', '').replace('cat__', '')
        name = name.replace('_', ' ')
        return name

    def explain_prediction(self, input_df):
        """
        Calculates exact SHAP contributions for the given input dataframe.
        Returns:
            dict containing:
                - base_value: expected value of the model
                - contributions: list of dicts with feature name, patient value, shap value, direction
                - top_positive: top features increasing heart disease likelihood
                - top_negative: top features decreasing heart disease likelihood
                - waterfall_b64: base64 encoded waterfall chart PNG
                - importance_b64: base64 encoded horizontal bar chart PNG
                - summary_text: plain-language narrative of the explanation
        """
        # Transform input using the pipeline's fitted preprocessor
        X_trans = self.preprocessor.transform(input_df)
        shap_vals = self.explainer.shap_values(X_trans)

        # Handle binary classification shapes
        if isinstance(shap_vals, list):
            vals = shap_vals[1][0]  # Class 1 (Heart Disease)
        elif len(shap_vals.shape) == 3:
            vals = shap_vals[0, :, 1]
        else:
            vals = shap_vals[0]

        expected_val = self.explainer.expected_value
        if isinstance(expected_val, (list, np.ndarray)):
            expected_val = float(expected_val[1]) if len(expected_val) > 1 else float(expected_val[0])
        else:
            expected_val = float(expected_val)

        # Pair each transformed feature with its SHAP value
        contributions = []
        for feat_name, s_val in zip(self.encoded_feature_names, vals):
            clean_name = self._clean_feature_name(feat_name)
            
            # Map back to raw input value for display
            orig_col = None
            for col in input_df.columns:
                if col.lower() in feat_name.lower():
                    orig_col = col
                    break
            raw_val = input_df[orig_col].values[0] if orig_col else "Present"

            contributions.append({
                'feature_raw': feat_name,
                'feature_name': clean_name,
                'patient_value': raw_val,
                'shap_value': round(float(s_val), 4),
                'impact': 'Increases Risk' if s_val > 0 else 'Lowers Risk',
                'abs_shap': abs(float(s_val))
            })

        # Sort by absolute contribution
        contributions.sort(key=lambda x: x['abs_shap'], reverse=True)

        positive_drivers = [c for c in contributions if c['shap_value'] > 0]
        negative_drivers = [c for c in contributions if c['shap_value'] < 0]

        # Generate charts
        waterfall_b64 = self._generate_waterfall_plot(contributions[:10], expected_val)
        importance_b64 = self._generate_importance_plot(contributions[:10])

        # Generate plain-language summary
        summary_paragraphs = self._generate_narrative(positive_drivers[:3], negative_drivers[:3])

        return {
            'expected_value': round(expected_val, 4),
            'contributions': contributions,
            'top_positive': positive_drivers[:5],
            'top_negative': negative_drivers[:5],
            'waterfall_b64': waterfall_b64,
            'importance_b64': importance_b64,
            'narrative': summary_paragraphs
        }

    def _generate_importance_plot(self, top_contributions):
        """Generates a modern, clean horizontal bar chart using the app's palette."""
        plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
        fig, ax = plt.subplots(figsize=(8, 4.5), dpi=150)
        fig.patch.set_facecolor('#FFFFFF')
        ax.set_facecolor('#F8FAFC')

        names = [c['feature_name'] for c in reversed(top_contributions)]
        values = [c['shap_value'] for c in reversed(top_contributions)]
        colors = ['#DC2626' if v > 0 else '#0F172A' for v in values]

        bars = ax.barh(names, values, color=colors, height=0.6, edgecolor='none')
        ax.axvline(0, color='#64748B', linewidth=0.8, linestyle='--')

        ax.set_title('Top Feature Contributions to Model Prediction (SHAP)', fontsize=12, fontweight='bold', color='#0F172A', pad=12)
        ax.set_xlabel('SHAP Impact on Heart Disease Output (Red = Increases Likelihood, Navy = Decreases)', fontsize=9, color='#64748B')
        ax.tick_params(colors='#0F172A', labelsize=9)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_color('#CBD5E1')
        ax.spines['bottom'].set_color('#CBD5E1')

        for bar, val in zip(bars, values):
            offset = 0.01 if val >= 0 else -0.01
            ha = 'left' if val >= 0 else 'right'
            ax.text(val + offset, bar.get_y() + bar.get_height()/2, f"{val:+.3f}",
                    va='center', ha=ha, fontsize=8, fontweight='bold', color='#0F172A')

        plt.tight_layout()
        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        return base64.b64encode(buf.getvalue()).decode('utf-8')

    def _generate_waterfall_plot(self, top_contributions, expected_value):
        """Generates an intuitive cumulative waterfall-style chart."""
        plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
        fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
        fig.patch.set_facecolor('#FFFFFF')
        ax.set_facecolor('#F8FAFC')

        # Compute running total
        items = list(reversed(top_contributions))
        names = [f"{c['feature_name']} ({c['patient_value']})" for c in items]
        deltas = [c['shap_value'] for c in items]

        current = expected_value
        bottoms = []
        for d in deltas:
            if d >= 0:
                bottoms.append(current)
                current += d
            else:
                bottoms.append(current + d)
                current += d

        colors = ['#DC2626' if d >= 0 else '#2563EB' for d in deltas]
        bars = ax.barh(names, [abs(d) for d in deltas], left=bottoms, color=colors, height=0.6)

        ax.axvline(expected_value, color='#64748B', linestyle=':', label=f'Baseline ({expected_value:.2f})')
        ax.set_title('Cumulative Feature Impact Waterfall Chart', fontsize=12, fontweight='bold', color='#0F172A', pad=12)
        ax.set_xlabel('Model Score Progression (Baseline to Final Prediction)', fontsize=9, color='#64748B')
        ax.tick_params(colors='#0F172A', labelsize=8.5)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_color('#CBD5E1')
        ax.spines['bottom'].set_color('#CBD5E1')

        plt.tight_layout()
        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        return base64.b64encode(buf.getvalue()).decode('utf-8')

    def _generate_narrative(self, top_pos, top_neg):
        """Produces clear, medical-grade educational narrative explaining SHAP results."""
        pos_notes = []
        for p in top_pos:
            pos_notes.append(f"**{p['feature_name']}** ({p['patient_value']}) was a primary factor elevating the prediction score (+{p['shap_value']:.3f}).")

        neg_notes = []
        for n in top_neg:
            neg_notes.append(f"**{n['feature_name']}** ({n['patient_value']}) served as a protective indicator lowering the prediction score ({n['shap_value']:.3f}).")

        narrative = {
            'positive_summary': " ".join(pos_notes) if pos_notes else "No significant elevated risk factors identified.",
            'negative_summary': " ".join(neg_notes) if neg_notes else "No protective parameters identified.",
            'conclusion': "The final prediction is derived by summing the baseline dataset rate with all individual positive and negative contributions."
        }
        return narrative

shap_service = ShapService()
